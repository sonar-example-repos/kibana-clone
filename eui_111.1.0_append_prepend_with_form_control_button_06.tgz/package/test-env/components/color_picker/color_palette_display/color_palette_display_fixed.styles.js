"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiColorPaletteDisplayFixed__bleedArea = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

// In a few screen sizes the palette display doesn't get a fully 100% width -
// it gets 1px less on width. For this reason we're adding a horizontal 1px bleed area
var euiColorPaletteDisplayFixed__bleedArea = exports.euiColorPaletteDisplayFixed__bleedArea = /*#__PURE__*/(0, _react.css)("position:absolute;inset:0;", (0, _global_styling.logicalCSS)('right', '-1px'), " display:flex;;label:euiColorPaletteDisplayFixed__bleedArea;");
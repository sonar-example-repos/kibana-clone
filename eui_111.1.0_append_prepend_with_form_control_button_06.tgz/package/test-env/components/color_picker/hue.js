"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiHue = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireDefault(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _classnames = _interopRequireDefault(require("classnames"));
var _services = require("../../services");
var _accessibility = require("../accessibility");
var _i18n = require("../i18n");
var _hue = require("./hue.styles");
var _tool_tip = require("../tool_tip");
var _react2 = require("@emotion/react");
var _excluded = ["className", "hex", "hue", "id", "onChange"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var HUE_RANGE = 359;
var EuiHue = exports.EuiHue = function EuiHue(_ref) {
  var className = _ref.className,
    hex = _ref.hex,
    _ref$hue = _ref.hue,
    hue = _ref$hue === void 0 ? 1 : _ref$hue,
    id = _ref.id,
    onChange = _ref.onChange,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var classes = (0, _classnames.default)('euiHue', className);
  var styles = (0, _services.useEuiMemoizedStyles)(_hue.euiHueStyles);
  var _useEuiI18n = (0, _i18n.useEuiI18n)(['euiHue.ariaValueText', 'euiHue.ariaRoleDescription'], ['Hue', 'Hue slider']),
    _useEuiI18n2 = (0, _slicedToArray2.default)(_useEuiI18n, 2),
    ariaValueText = _useEuiI18n2[0],
    ariaRoleDescription = _useEuiI18n2[1];
  var handleChange = function handleChange(e) {
    onChange(Number(e.target.value));
  };
  var hueValue = typeof hue === 'string' ? parseInt(hue) : hue;
  // align the tooltip contextually closer to the thumb
  var tooltipPosition = hueValue < Math.floor(HUE_RANGE / 2) ? 'left' : 'right';
  return (0, _react2.jsx)("div", {
    css: styles.euiHue,
    className: classes
  }, (0, _react2.jsx)(_accessibility.EuiScreenReaderOnly, null, (0, _react2.jsx)("label", {
    htmlFor: "".concat(id, "-hue")
  }, (0, _react2.jsx)(_i18n.EuiI18n, {
    token: "euiHue.label",
    default: "Select the HSV color mode 'hue' value"
  }))), (0, _react2.jsx)(_tool_tip.EuiToolTip, {
    content: hex,
    anchorProps: {
      css: styles.euiHue__tooltip
    },
    disableScreenReaderOutput: true,
    position: tooltipPosition
  }, (0, _react2.jsx)("input", (0, _extends2.default)({
    id: "".concat(id, "-hue"),
    min: 0,
    max: HUE_RANGE,
    step: 1,
    type: "range",
    css: styles.euiHue__range,
    className: "euiHue__range",
    value: hue,
    onChange: handleChange,
    "aria-roledescription": ariaRoleDescription,
    "aria-valuetext": "".concat(ariaValueText, " ").concat(hue, "\xB0")
  }, rest))));
};
EuiHue.propTypes = {
  className: _propTypes.default.string,
  "aria-label": _propTypes.default.string,
  "data-test-subj": _propTypes.default.string,
  css: _propTypes.default.any,
  hex: _propTypes.default.string,
  hue: _propTypes.default.oneOfType([_propTypes.default.string.isRequired, _propTypes.default.number.isRequired]),
  onChange: _propTypes.default.func.isRequired
};
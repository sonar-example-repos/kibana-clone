"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiCollapsibleNavButton", {
  enumerable: true,
  get: function get() {
    return _collapsible_nav_button.EuiCollapsibleNavButton;
  }
});
var _collapsible_nav_button = require("./collapsible_nav_button");
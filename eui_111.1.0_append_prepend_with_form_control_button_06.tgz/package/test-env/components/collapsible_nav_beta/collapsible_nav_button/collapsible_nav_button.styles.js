"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiCollapsibleNavButtonWrapperStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
var _header = require("../../header/header.styles");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "msjxar-euiCollapsibleNavButton",
  styles: "&.euiButtonIcon:hover{transform:none;};label:euiCollapsibleNavButton;"
} : {
  name: "msjxar-euiCollapsibleNavButton",
  styles: "&.euiButtonIcon:hover{transform:none;};label:euiCollapsibleNavButton;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiCollapsibleNavButtonWrapperStyles = exports.euiCollapsibleNavButtonWrapperStyles = function euiCollapsibleNavButtonWrapperStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  var _euiHeaderVariables = (0, _header.euiHeaderVariables)(euiThemeContext),
    height = _euiHeaderVariables.height,
    padding = _euiHeaderVariables.padding;
  return {
    euiCollapsibleNavButtonWrapper: /*#__PURE__*/(0, _react.css)("display:flex;align-items:center;justify-content:center;", (0, _global_styling.logicalSizeCSS)(height), ";;label:euiCollapsibleNavButtonWrapper;"),
    euiCollapsibleNavButton: _ref,
    left: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('border-right', euiTheme.border.thin), " ", (0, _global_styling.logicalCSS)('margin-left', "-".concat(padding)), " ", (0, _global_styling.logicalCSS)('margin-right', padding), ";;label:left;"),
    right: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('border-left', euiTheme.border.thin), " ", (0, _global_styling.logicalCSS)('margin-right', "-".concat(padding)), " ", (0, _global_styling.logicalCSS)('margin-left', padding), ";;label:right;")
  };
};
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiCollapsedNavItem", {
  enumerable: true,
  get: function get() {
    return _collapsed_nav_item.EuiCollapsedNavItem;
  }
});
var _collapsed_nav_item = require("./collapsed_nav_item");
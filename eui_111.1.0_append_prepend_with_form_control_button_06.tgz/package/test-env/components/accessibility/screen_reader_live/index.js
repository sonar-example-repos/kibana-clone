"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiScreenReaderLive", {
  enumerable: true,
  get: function get() {
    return _screen_reader_live.EuiScreenReaderLive;
  }
});
var _screen_reader_live = require("./screen_reader_live");
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TYPES = exports.TEXT_STYLES = exports.ROW_GUTTER_SIZES = exports.COLUMN_GUTTER_SIZES = exports.CHILD_TYPES = exports.ALIGNMENTS = void 0;
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var CHILD_TYPES = exports.CHILD_TYPES = ['row', 'inline', 'column'];
var TYPES = exports.TYPES = [].concat(CHILD_TYPES, ['responsiveColumn']);
var ALIGNMENTS = exports.ALIGNMENTS = ['center', 'left'];
var TEXT_STYLES = exports.TEXT_STYLES = ['normal', 'reverse'];
var ROW_GUTTER_SIZES = exports.ROW_GUTTER_SIZES = ['s', 'm'];
var COLUMN_GUTTER_SIZES = exports.COLUMN_GUTTER_SIZES = ['s', 'm'];
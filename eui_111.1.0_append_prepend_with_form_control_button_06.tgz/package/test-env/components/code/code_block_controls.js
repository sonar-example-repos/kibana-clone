"use strict";

var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiCodeBlockControls = void 0;
var _react = _interopRequireWildcard(require("react"));
var _services = require("../../services");
var _code_block_controls = require("./code_block_controls.styles");
var _react2 = require("@emotion/react");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var EuiCodeBlockControls = exports.EuiCodeBlockControls = function EuiCodeBlockControls(_ref) {
  var paddingSize = _ref.paddingSize,
    controls = _ref.controls;
  var styles = (0, _services.useEuiMemoizedStyles)(_code_block_controls.euiCodeBlockControlsStyles);
  var cssStyles = [styles.euiCodeBlock__controls, styles.offset[paddingSize]];
  var hasControls = controls.some(function (control) {
    return !!control;
  });
  return hasControls ? (0, _react2.jsx)("div", {
    className: "euiCodeBlock__controls",
    css: cssStyles
  }, controls.map(function (control, i) {
    return (0, _react2.jsx)(_react.Fragment, {
      key: i
    }, control);
  })) : null;
};
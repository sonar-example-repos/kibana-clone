"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useFullScreen = exports.EuiCodeBlockFullScreenWrapper = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _react = _interopRequireWildcard(require("react"));
var _services = require("../../services");
var _i18n = require("../i18n");
var _button = require("../button");
var _focus_trap = require("../focus_trap");
var _overlay_mask = require("../overlay_mask");
var _code_block = require("./code_block.styles");
var _delay_render = require("../delay_render");
var _react2 = require("@emotion/react");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * Hook that returns fullscreen-related state/logic/utils
 */
var useFullScreen = exports.useFullScreen = function useFullScreen(_ref) {
  var overflowHeight = _ref.overflowHeight;
  var toggleButtonRef = (0, _react.useRef)(null);
  var showFullScreenButton = !!overflowHeight;
  var _useState = (0, _react.useState)(false),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    isFullScreen = _useState2[0],
    setIsFullScreen = _useState2[1];
  var returnFocus = function returnFocus() {
    // uses timeout to ensure focus is placed after potential other updates happen
    setTimeout(function () {
      var _toggleButtonRef$curr;
      (_toggleButtonRef$curr = toggleButtonRef.current) === null || _toggleButtonRef$curr === void 0 || _toggleButtonRef$curr.focus();
    });
  };
  var toggleFullScreen = (0, _react.useCallback)(function () {
    setIsFullScreen(function (isFullScreen) {
      return !isFullScreen;
    });
    if (isFullScreen) {
      returnFocus();
    }
  }, [isFullScreen]);
  var onKeyDown = (0, _react.useCallback)(function (event) {
    if (event.key === _services.keys.ESCAPE) {
      // We need to make sure annotation Escape keypresses don't also cause fullscreen mode to close
      var focus = document.activeElement;
      var isAnnotationPopover = !!(focus !== null && focus !== void 0 && focus.dataset.popoverOpen) || !!(focus !== null && focus !== void 0 && focus.closest('[data-popover-open]'));
      if (!isAnnotationPopover) {
        event.preventDefault();
        event.stopPropagation();
        setIsFullScreen(false);
        returnFocus();
      }
    }
  }, []);
  var _useEuiI18n = (0, _i18n.useEuiI18n)(['euiCodeBlockFullScreen.fullscreenCollapse', 'euiCodeBlockFullScreen.fullscreenExpand'], ['Collapse', 'Expand']),
    _useEuiI18n2 = (0, _slicedToArray2.default)(_useEuiI18n, 2),
    fullscreenCollapse = _useEuiI18n2[0],
    fullscreenExpand = _useEuiI18n2[1];
  var fullScreenButton = (0, _react.useMemo)(function () {
    var button = (0, _react2.jsx)(_button.EuiButtonIcon, {
      buttonRef: toggleButtonRef,
      className: "euiCodeBlock__fullScreenButton",
      onClick: toggleFullScreen,
      iconType: isFullScreen ? 'fullScreenExit' : 'fullScreen',
      color: "text",
      "aria-label": isFullScreen ? fullscreenCollapse : fullscreenExpand
    });
    return showFullScreenButton ? isFullScreen ?
    // use delay to prevent label being updated in non-fullscreen state before fullscreen is opened
    // otherwise this causes screen readers to read the collapse label before anything else (as the button was focused when opening)
    (0, _react2.jsx)(_delay_render.EuiDelayRender, {
      delay: 10
    }, button) : button : null;
  }, [showFullScreenButton, toggleFullScreen, isFullScreen, fullscreenCollapse, fullscreenExpand]);
  return {
    fullScreenButton: fullScreenButton,
    isFullScreen: isFullScreen,
    onKeyDown: onKeyDown
  };
};

/**
 * Portalled full screen wrapper
 */
var EuiCodeBlockFullScreenWrapper = exports.EuiCodeBlockFullScreenWrapper = function EuiCodeBlockFullScreenWrapper(_ref2) {
  var children = _ref2.children,
    onClose = _ref2.onClose;
  var styles = (0, _services.useEuiMemoizedStyles)(_code_block.euiCodeBlockStyles);
  var cssStyles = [styles.euiCodeBlock, styles.l,
  // Force fullscreen to use large font
  styles.isFullScreen];
  var ariaLabel = (0, _i18n.useEuiI18n)('euiCodeBlockFullScreen.ariaLabel', 'Expanded code block');
  var dialogProps = {
    role: 'dialog',
    'aria-modal': true,
    'aria-label': ariaLabel,
    onKeyDown: onClose
  };
  return (0, _react2.jsx)(_overlay_mask.EuiOverlayMask, null, (0, _react2.jsx)(_focus_trap.EuiFocusTrap, {
    scrollLock: true,
    preventScrollOnFocus: true,
    clickOutsideDisables: true
  }, (0, _react2.jsx)("div", (0, _extends2.default)({
    className: "euiCodeBlockFullScreen",
    css: cssStyles
  }, dialogProps), children)));
};
EuiCodeBlockFullScreenWrapper.propTypes = {
  onClose: _propTypes.default.func.isRequired
};
"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiFocusTrap = void 0;
var _react = _interopRequireDefault(require("react"));
var _react2 = require("@emotion/react");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var EuiFocusTrap = exports.EuiFocusTrap = function EuiFocusTrap(_ref) {
  var children = _ref.children,
    dataTestSubj = _ref['data-test-subj'];
  return (0, _react2.jsx)("div", {
    "data-eui": "EuiFocusTrap",
    "data-test-subj": dataTestSubj
  }, children);
};
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiButtonEmpty", {
  enumerable: true,
  get: function get() {
    return _button_empty.EuiButtonEmpty;
  }
});
var _button_empty = require("./button_empty");
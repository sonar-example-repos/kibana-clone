"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiDataGridPagination", {
  enumerable: true,
  get: function get() {
    return _data_grid_pagination.EuiDataGridPagination;
  }
});
Object.defineProperty(exports, "shouldRenderPagination", {
  enumerable: true,
  get: function get() {
    return _data_grid_pagination.shouldRenderPagination;
  }
});
var _data_grid_pagination = require("./data_grid_pagination");
"use strict";

var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiFlyout = void 0;
var _react = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var EuiFlyout = exports.EuiFlyout = /*#__PURE__*/(0, _react.forwardRef)(function (_ref, ref) {
  var _ref$as = _ref.as,
    as = _ref$as === void 0 ? 'div' : _ref$as,
    _ref$role = _ref.role,
    role = _ref$role === void 0 ? 'dialog' : _ref$role,
    children = _ref.children,
    closeButtonProps = _ref.closeButtonProps,
    hideCloseButton = _ref.hideCloseButton,
    onClose = _ref.onClose,
    onKeyDown = _ref.onKeyDown,
    dataTestSubj = _ref['data-test-subj'];
  var Element = as;
  return (0, _react2.jsx)(Element, {
    ref: ref,
    "data-eui": "EuiFlyout",
    "data-test-subj": dataTestSubj,
    role: role,
    onKeyDown: onKeyDown
  }, !hideCloseButton && (0, _react2.jsx)("button", {
    type: "button",
    "data-test-subj": "euiFlyoutCloseButton",
    "aria-label": "Close this dialog",
    onClick: function onClick(e) {
      onClose();
      (closeButtonProps === null || closeButtonProps === void 0 ? void 0 : closeButtonProps.onClick) && closeButtonProps.onClick(e);
    }
  }), children);
});
EuiFlyout.displayName = 'EuiFlyout';
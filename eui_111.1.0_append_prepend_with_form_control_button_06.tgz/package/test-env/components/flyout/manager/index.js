"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiFlyoutChild", {
  enumerable: true,
  get: function get() {
    return _flyout_child.EuiFlyoutChild;
  }
});
Object.defineProperty(exports, "EuiFlyoutMain", {
  enumerable: true,
  get: function get() {
    return _flyout_main.EuiFlyoutMain;
  }
});
Object.defineProperty(exports, "EuiFlyoutManager", {
  enumerable: true,
  get: function get() {
    return _provider.EuiFlyoutManager;
  }
});
Object.defineProperty(exports, "addFlyoutAction", {
  enumerable: true,
  get: function get() {
    return _actions.addFlyout;
  }
});
Object.defineProperty(exports, "closeFlyoutAction", {
  enumerable: true,
  get: function get() {
    return _actions.closeFlyout;
  }
});
Object.defineProperty(exports, "flyoutManagerReducer", {
  enumerable: true,
  get: function get() {
    return _reducer.flyoutManagerReducer;
  }
});
Object.defineProperty(exports, "getWidthFromSize", {
  enumerable: true,
  get: function get() {
    return _layout_mode.getWidthFromSize;
  }
});
Object.defineProperty(exports, "initialState", {
  enumerable: true,
  get: function get() {
    return _reducer.initialState;
  }
});
Object.defineProperty(exports, "setActiveFlyoutAction", {
  enumerable: true,
  get: function get() {
    return _actions.setActiveFlyout;
  }
});
Object.defineProperty(exports, "setActivityStageAction", {
  enumerable: true,
  get: function get() {
    return _actions.setActivityStage;
  }
});
Object.defineProperty(exports, "setFlyoutWidthAction", {
  enumerable: true,
  get: function get() {
    return _actions.setFlyoutWidth;
  }
});
Object.defineProperty(exports, "setPushPaddingAction", {
  enumerable: true,
  get: function get() {
    return _actions.setPushPadding;
  }
});
Object.defineProperty(exports, "useCurrentChildFlyout", {
  enumerable: true,
  get: function get() {
    return _hooks.useCurrentChildFlyout;
  }
});
Object.defineProperty(exports, "useCurrentMainFlyout", {
  enumerable: true,
  get: function get() {
    return _hooks.useCurrentMainFlyout;
  }
});
Object.defineProperty(exports, "useCurrentSession", {
  enumerable: true,
  get: function get() {
    return _hooks.useCurrentSession;
  }
});
Object.defineProperty(exports, "useFlyoutId", {
  enumerable: true,
  get: function get() {
    return _hooks.useFlyoutId;
  }
});
Object.defineProperty(exports, "useFlyoutLayoutMode", {
  enumerable: true,
  get: function get() {
    return _hooks.useFlyoutLayoutMode;
  }
});
Object.defineProperty(exports, "useFlyoutManager", {
  enumerable: true,
  get: function get() {
    return _hooks.useFlyoutManager;
  }
});
Object.defineProperty(exports, "useFlyoutWidth", {
  enumerable: true,
  get: function get() {
    return _hooks.useFlyoutWidth;
  }
});
Object.defineProperty(exports, "useHasActiveSession", {
  enumerable: true,
  get: function get() {
    return _hooks.useHasActiveSession;
  }
});
Object.defineProperty(exports, "useHasChildFlyout", {
  enumerable: true,
  get: function get() {
    return _hooks.useHasChildFlyout;
  }
});
Object.defineProperty(exports, "useHasPushPadding", {
  enumerable: true,
  get: function get() {
    return _hooks.useHasPushPadding;
  }
});
Object.defineProperty(exports, "useIsFlyoutActive", {
  enumerable: true,
  get: function get() {
    return _hooks.useIsFlyoutActive;
  }
});
Object.defineProperty(exports, "useIsInManagedFlyout", {
  enumerable: true,
  get: function get() {
    return _hooks.useIsInManagedFlyout;
  }
});
Object.defineProperty(exports, "useParentFlyoutSize", {
  enumerable: true,
  get: function get() {
    return _hooks.useParentFlyoutSize;
  }
});
Object.defineProperty(exports, "usePushPaddingOffsets", {
  enumerable: true,
  get: function get() {
    return _hooks.usePushPaddingOffsets;
  }
});
var _actions = require("./actions");
var _reducer = require("./reducer");
var _provider = require("./provider");
var _hooks = require("./hooks");
var _flyout_child = require("./flyout_child");
var _flyout_main = require("./flyout_main");
var _layout_mode = require("./layout_mode");
"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiFlyoutChild = EuiFlyoutChild;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireDefault(require("react"));
var _services = require("../../../services");
var _flyout_managed = require("./flyout_managed");
var _hooks = require("./hooks");
var _const = require("./const");
var _const2 = require("../const");
var _react2 = require("@emotion/react");
var _excluded = ["css", "side"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
/**
 * Props for `EuiFlyoutChild`, a managed child flyout that pairs with a main flyout.
 *
 * Notes:
 * - `type`, `side`, and `level` are fixed by the component and thus omitted.
 */
/**
 * Managed child flyout that renders alongside or stacked over the main flyout,
 * depending on the current layout mode. Handles required managed flyout props.
 */
function EuiFlyoutChild(_ref) {
  var customCss = _ref.css,
    _ref$side = _ref.side,
    side = _ref$side === void 0 ? _const2.DEFAULT_SIDE : _ref$side,
    props = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var _useEuiTheme = (0, _services.useEuiTheme)(),
    euiTheme = _useEuiTheme.euiTheme;
  var mainFlyout = (0, _hooks.useCurrentMainFlyout)();
  var mainWidth = (0, _hooks.useFlyoutWidth)(mainFlyout === null || mainFlyout === void 0 ? void 0 : mainFlyout.flyoutId);
  var layoutMode = (0, _hooks.useFlyoutLayoutMode)();

  // Runtime validation: prevent orphan child flyouts
  if (!mainFlyout) {
    var errorMessage = 'EuiFlyoutChild must be used with an EuiFlyoutMain. ' + 'This usually means the main flyout was not rendered before the child flyout.';

    // In development, throw an error to catch the issue early
    if (process.env.NODE_ENV === 'development') {
      throw new Error(errorMessage);
    }

    // In production, log a warning and prevent rendering
    console.error('EuiFlyoutChild validation failed:', errorMessage);
    return null;
  }
  var style = {};
  if (mainWidth && layoutMode === _const.LAYOUT_MODE_SIDE_BY_SIDE) {
    style = (0, _defineProperty2.default)({}, side, mainWidth);
  } else if (layoutMode === _const.LAYOUT_MODE_STACKED) {
    style = {
      zIndex: Number(euiTheme.levels.flyout) + 2
    };
  }
  return (0, _react2.jsx)(_flyout_managed.EuiManagedFlyout, (0, _extends2.default)({}, props, {
    style: style,
    level: _const.LEVEL_CHILD,
    type: "overlay",
    ownFocus: false,
    side: side,
    css: customCss
  }));
}
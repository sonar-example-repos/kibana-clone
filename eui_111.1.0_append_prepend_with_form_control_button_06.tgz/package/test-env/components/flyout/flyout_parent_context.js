"use strict";

var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useIsInsideParentFlyout = exports.EuiFlyoutParentProvider = void 0;
var _react = _interopRequireWildcard(require("react"));
var _react2 = require("@emotion/react");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * Context to track if we're inside a parent flyout's children.
 * This allows nested flyouts to automatically inherit the session
 * without requiring explicit `session="inherit"` prop.
 */var EuiFlyoutParentContext = /*#__PURE__*/(0, _react.createContext)(false);

/**
 * Provider that wraps a flyout's children to indicate they're inside a parent flyout.
 * Nested flyouts can use this to automatically default to session inheritance.
 */
var EuiFlyoutParentProvider = exports.EuiFlyoutParentProvider = function EuiFlyoutParentProvider(_ref) {
  var children = _ref.children;
  return (0, _react2.jsx)(EuiFlyoutParentContext.Provider, {
    value: true
  }, children);
};

/**
 * Hook that returns `true` when called within a parent flyout's children.
 * Used to automatically determine if a nested flyout should inherit the session.
 */
var useIsInsideParentFlyout = exports.useIsInsideParentFlyout = function useIsInsideParentFlyout() {
  return (0, _react.useContext)(EuiFlyoutParentContext);
};
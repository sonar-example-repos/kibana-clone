"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CustomItemAction = void 0;
var _react = _interopRequireDefault(require("react"));
var _react2 = require("@emotion/react");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var CustomItemAction = exports.CustomItemAction = function CustomItemAction(_ref) {
  var action = _ref.action,
    enabled = _ref.enabled,
    item = _ref.item,
    className = _ref.className;
  return (0, _react2.jsx)("div", {
    className: className
  }, action.render(item, enabled));
};